import { Component } from '@angular/core';
import { DataService } from './data.service';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Http , Response } from '@angular/http'; 
import { Observable } from 'rxjs/Observable'; 
import { Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  EmpExpenseData: Array<any>;
  myssn:string = "123456789";
  custdata;
  
  constructor(private _dataService: DataService, private httpService: HttpClient,private _http: Http) {
     
  }
//constructor end
  // ADD CHART OPTIONS. 
  pieChartOptions = {
    responsive: true
}

pieChartLabels =  ['Rent', 'Maid', 'Travelling', 'Grocery', 'Investment' , 'Personal_Expense'];

  // CHART COLOR.
  pieChartColor:any = [
    {
        backgroundColor: ['rgba(30, 169, 224, 0.8)',
        'rgba(255,165,0,0.9)',
        'rgba(139, 136, 136, 0.9)',
        'rgba(255, 161, 181, 0.9)',
        'rgba(255, 102, 0, 0.9)',
        'rgba(255, 50, 0, 0.9)'
        ]
    }
]



ngOnInit () 
{
  this._dataService.getUsers().subscribe(
    data =>
    {
      this.EmpExpenseData=data;
      var i:number;
      for(let empdata in this.EmpExpenseData) {
        console.log(empdata[0])
     }

      // alert("data: "+ data[0].Rent);
     
      this.pieChartData=[data[1].Rent,data[1].Maid,data[1].Travelling,data[1].Grocery,data[1].Investment,data[1].PersonalExpense];

      
    }); 
}

// public pieChartData: Number[]=[1000,2000,3000,4000,5000,6000];
public pieChartData: Number[]=[];

onChartClick(event) {
  console.log(event);
}


}
